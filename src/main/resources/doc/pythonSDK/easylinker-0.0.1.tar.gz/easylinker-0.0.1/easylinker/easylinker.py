﻿# coding: UTF-8                                
import threading
import paho.mqtt.client as mqtt
import time
SERVER_HOST = "47.94.173.41"
SERVER_PORT = 1883

class EasyLinkerApp:

    def on_connect(self, client, userdata, flags, rc):
        print('Device  [%s]  Connected Success!' % self.device_id)
        client.subscribe("device/" + self.device_id)

    def disconnect(self):
        self.mqtt_client.disconnect()
        self.threading.stopped=True
        print('Device  [%s]  Disconnected!' % self.device_id)

    def mqtt_connect(self):
        try:
            self.mqtt_client.connect(SERVER_HOST, SERVER_PORT, 60)
            self.mqtt_client.loop_forever()
        except Exception:
            self.disconnect()
            print("error001!")
            

    def run(self):
            print("Start......")
            self.threading.start()



    def publish(self, message,value_name):
        self.mqtt_client.publish("device/"+self.device_type,str({"username":self.device_id,"name":value_name,"message":message}))

    def __init__(self, device_id,device_type, on_message):
        self.device_type=device_type;

        self.device_id = device_id
        self.server_host = SERVER_HOST
        self.server_port = SERVER_PORT
        self.mqtt_client = mqtt.Client()
        self.mqtt_client.on_connect = self.on_connect
        self.mqtt_client.on_message = on_message
        self.mqtt_client.on_disconnect=self.disconnect
        self.mqtt_client.username_pw_set(self.device_id)
        self.dev_mode = False
        self.threading =threading.Thread(target = self.mqtt_connect)
