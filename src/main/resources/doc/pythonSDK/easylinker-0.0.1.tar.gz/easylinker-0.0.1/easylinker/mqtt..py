# -*- coding: utf-8 -*-  
import paho.mqtt.client as mqtt

        
# 连接成功回调函数
def on_connect(client, userdata, flags, rc):
    print('Connected')
    client.subscribe("TYPE_VALUE/640ae24c-ae6b-4cc9-99cb-341d8b292366")
    #client.publish("/DISCONNECTED","DISCONNECTED")

# 消息推送回调函数
def on_message(client, userdata, msg):
    print(msg.topic+" "+str(msg.payload))

if __name__ == '__main__':
    client = mqtt.Client()
    client.username_pw_set("640ae24c-ae6b-4cc9-99cb-341d8b292366", password=None)
    client.on_connect = on_connect

    client.on_message = on_message
    
    try:
        # 请根据实际情况改变MQTT代理服务器的IP地址
        client.connect("localhost", 1884, 60)
        client.loop_forever()
    except KeyboardInterrupt:
        client.disconnect()
